// =============================================================
// StatusWindow — 浮気した妻 ステータス（常時有効ウィジェット）
// -------------------------------------------------------------
// ・公式サンプル StatusWindow を、この作品の作風（裏切りから半年、夫婦をやり直そうとする静かな家庭劇）に
//   合わせて描き直したもの。関数名とタグの書式（place・time・date・weather・cast）はサンプルと同じ。
//   プロンプトとプレビュー用タグは StatusWindow_prompt.md。
// ・状態は保持しない。描くのは毎回タグの値（props）だけ。
//   useState は表示中だけのこと（人物のタブ、胸の内の開閉、画像の読み込み失敗、画面に見えているか）にだけ使う。
// ・props が無い・空・不正な値でも描ける。時刻・天気・cast は、書き方が多少ずれても読む（readTime / readWeather / readCast）。
// ・上の風景は「家の窓から見た外」。時刻で空の色と街の明かりが変わり、天気で雨・雪・桜が窓の外に降る。
//   過去のメッセージのウィジェットも描き直されるので、画面の外にあるあいだは降るもののアニメを止める。
// ・胸の内（thought）は、ボタンを押すまでぼかしておく。本文は主人公の視点なので、相手の本音はここでだけ読める。
// ・スタイルの文字列は STYLE と呼ぶ（CSS と名付けると、ブラウザの CSS.supports が隠れる）。
// =============================================================

const LABEL = {
  font: 'Shippori Mincho',
  somewhere: 'どこか',
  nobody: 'そばには誰もいない',
  period: { late: '深夜', dawn: '明け方', morning: '朝', day: '昼', dusk: '夕方', night: '夜' },
  weather: { clear: '晴れ', cloudy: 'くもり', rain: '雨', snow: '雪', petals: '桜' },
  outfit: '服装',
  action: '様子',
  thought: '胸の内',
  peek: '胸の内をのぞく',
  hide: 'しまう',
};

// 並び順。ここにある人はタグの順番にかかわらず先頭に出す（最初に開くタブになる）。ほかの人はタグの順。
const ORDER = ['瑞穂'];

// 顔の画像。名前ごとに https のURLを入れると、タグに image が無くても肖像が出る（タグの image より優先）。
// 成人向けの画像は GitHub に置かず、pinxai に登録したキャラの画像
// （チャットルームAPIの characters[].avatar.urls.preview）のURLを使う。
// 空のとき・読み込めないときは、名前の最初の1文字を描く。
const PORTRAITS = {
  瑞穂: '',
};

// AI が英語のキーではなく日本語で書いてきたときの読み替え。
const WEATHER_WORDS = {
  晴れ: 'clear', 晴: 'clear', 快晴: 'clear', sunny: 'clear',
  くもり: 'cloudy', 曇り: 'cloudy', 曇: 'cloudy',
  雨: 'rain', 小雨: 'rain', 大雨: 'rain',
  雪: 'snow',
  桜: 'petals', 花びら: 'petals', 桜吹雪: 'petals',
};

// 時間帯ごとの空（上→下）、街（遠い→近い）、窓の明かりが点いている割合、太陽・月の光、星の明るさ、強調色。
// どれもくすませてある。夜は窓の明かりを多めにし、深夜は少し残すだけにする。
const SKY = {
  late: { sky: ['#03050b', '#080c1a', '#10162b', '#192038'], city: ['#151b2e', '#0b0e19'], lit: 0.07, glow: '#dfe4ff', stars: 1, accent: '#9aa3cf' },
  dawn: { sky: ['#1b2040', '#4a4868', '#97808e', '#d6b7a6'], city: ['#4a4560', '#26233a'], lit: 0.1, glow: '#ffd9b8', stars: 0.3, accent: '#d7a99f' },
  morning: { sky: ['#5b7593', '#8aa2b9', '#bfcbd6', '#e4e2dc'], city: ['#8592a3', '#4e5868'], lit: 0, glow: '#fff6e6', stars: 0, accent: '#a8bccf' },
  day: { sky: ['#4b76a1', '#7b9fc2', '#b1c6d9', '#dbe3e9'], city: ['#7f8fa3', '#4a5668'], lit: 0, glow: '#fffaf0', stars: 0, accent: '#9db6ce' },
  dusk: { sky: ['#272444', '#664864', '#bd7862', '#e5b089'], city: ['#5a4258', '#2a1f30'], lit: 0.22, glow: '#ffbf8a', stars: 0.1, accent: '#dfa07c' },
  night: { sky: ['#060914', '#0d142c', '#1b2444', '#2b3355'], city: ['#1b2238', '#0e1220'], lit: 0.42, glow: '#e6eaff', stars: 0.6, accent: '#aab3df' },
};

const STYLE = `
@import url('https://fonts.googleapis.com/css2?family=${LABEL.font.replace(/ /g, '+')}:wght@400;600&display=swap');
.sw { --serif: '${LABEL.font}', 'Yu Mincho', 'Hiragino Mincho ProN', serif; --ink: #ebe6dd; --muted: #a39e95; --rule: #ffffff12;
  --accent-soft: color-mix(in srgb, var(--accent) 34%, transparent);
  position: relative; border-radius: 14px; overflow: hidden; container-type: inline-size; color: var(--ink);
  overflow-wrap: anywhere; isolation: isolate;
  background: #141418; background: linear-gradient(180deg, #18181e 0%, #111115 100%);
  box-shadow: 0 0 0 1px #ffffff14, 0 16px 36px -22px #000;
  animation: sw-in .7s ease-out both; }

/* 窓の外 */
.sw-view { position: relative; height: 118px; overflow: hidden; background: var(--s3); }
.sw-scene { position: absolute; inset: 0; }
.sw-sky { position: absolute; inset: 0; background: linear-gradient(180deg, var(--s0) 0%, var(--s1) 40%, var(--s2) 76%, var(--s3) 100%); }
.sw[data-weather=cloudy] .sw-scene, .sw[data-weather=snow] .sw-scene { filter: saturate(.55) brightness(.9); }
.sw[data-weather=rain] .sw-scene { filter: saturate(.45) brightness(.78) blur(.6px); }
.sw-sun { position: absolute; width: 90px; height: 90px; margin: -45px 0 0 -45px; border-radius: 50%;
  background: radial-gradient(circle, var(--glow) 0 10%, color-mix(in srgb, var(--glow) 45%, transparent) 26%, transparent 66%); }
.sw-moon { position: absolute; width: 22px; height: 22px; margin: -11px 0 0 -11px; border-radius: 50%;
  background: radial-gradient(circle at 68% 32%, #0000 44%, #f4f0df 46%); filter: drop-shadow(0 0 8px #f4f0df88); }
.sw[data-weather=cloudy] .sw-sun, .sw[data-weather=rain] .sw-sun, .sw[data-weather=snow] .sw-sun,
.sw[data-weather=cloudy] .sw-moon, .sw[data-weather=rain] .sw-moon, .sw[data-weather=snow] .sw-moon { opacity: .25; filter: blur(3px); }
.sw-star { position: absolute; width: 2px; height: 2px; border-radius: 50%; background: #fff;
  opacity: var(--o); animation: sw-twinkle var(--d) ease-in-out infinite alternate; }
.sw-cloud { position: absolute; height: 40%; aspect-ratio: 4; border-radius: 999px; background: #c9ced8;
  opacity: .22; filter: blur(18px); animation: sw-drift 50s linear infinite alternate; }
.sw-city { position: absolute; left: 0; bottom: 0; width: 100%; height: 66px; }
.sw-city .far { fill: var(--c0); }
.sw-city .near { fill: var(--c1); }
.sw-city .lit { fill: #ffd69a; filter: drop-shadow(0 0 2px #ffb85a); }
.sw-fall { position: absolute; inset: 0; overflow: hidden; pointer-events: none; }
.sw-fall i { position: absolute; left: var(--x); top: -24px; }
.sw-fall .rain { width: 1px; height: var(--h); background: linear-gradient(transparent, #dce6f5a0);
  animation: sw-rain var(--t) linear var(--w) infinite; }
.sw-fall .snow { width: var(--h); height: var(--h); border-radius: 50%; background: #f4f6fb; opacity: .85;
  animation: sw-snow var(--t) linear var(--w) infinite; }
.sw-fall .petal { width: 8px; height: 5px; border-radius: 8px 1px 8px 1px; background: linear-gradient(135deg, #fbe4ea, #e9a9ba);
  opacity: .85; animation: sw-petal var(--t) linear var(--w) infinite; }
/* 窓ガラスについた雨粒。いくつかはゆっくり流れ落ちる */
.sw-fall .bead { top: var(--y); width: var(--h); height: calc(var(--h) * 1.15); border-radius: 50% 50% 48% 48%;
  background: radial-gradient(circle at 38% 32%, #ffffff70 0 10%, #ffffff1c 32%, #ffffff0a 60%, transparent 70%);
  box-shadow: 0 1px 1px #00000030; }
.sw-fall .bead.slide { animation: sw-slide var(--t) ease-in var(--w) infinite; }
.sw-glass { position: absolute; inset: 0; pointer-events: none;
  background: linear-gradient(112deg, transparent 22%, #ffffff0c 30%, transparent 38%, transparent 62%, #ffffff08 68%, transparent 74%); }
/* 右端のレースのカーテン。ひだは薄く、ぼかしてある */
.sw-curtain { position: absolute; top: 0; bottom: 0; right: 0; width: 18%; pointer-events: none; filter: blur(1.5px);
  background: repeating-linear-gradient(90deg, #f5efe608 0 9px, #f5efe617 13px, #f5efe608 20px), linear-gradient(90deg, #f5efe600, #f5efe626);
  -webkit-mask-image: linear-gradient(90deg, transparent, #000 55%); mask-image: linear-gradient(90deg, transparent, #000 55%); }
.sw-frame { position: absolute; inset: 0; pointer-events: none; box-shadow: inset 0 0 0 6px #0c0c10, inset 0 0 0 7px #ffffff10; }
.sw-frame::before { content: ''; position: absolute; top: 0; bottom: 0; left: calc(50% - 3px); width: 6px; background: #0c0c10;
  box-shadow: -1px 0 0 #ffffff10, 1px 0 0 #ffffff10; }
.sw[data-live=off] .sw-view * { animation-play-state: paused; }

/* 日付・場所・時刻 */
.sw-head { display: flex; flex-wrap: wrap; align-items: flex-end; justify-content: space-between; gap: 6px 14px;
  padding: 12px 16px 10px; border-bottom: 1px solid var(--rule); }
.sw-where { min-width: 0; }
.sw-date { display: block; font-size: 11px; letter-spacing: .14em; color: var(--muted); }
.sw-place { display: block; margin-top: 2px; font: 600 19px/1.35 var(--serif); letter-spacing: .05em; }
.sw-clock { margin-left: auto; text-align: right; white-space: nowrap; }
.sw-clock b { display: block; font: 400 24px/1.1 var(--serif); letter-spacing: .06em; font-variant-numeric: tabular-nums; }
.sw-clock span { font-size: 11px; letter-spacing: .14em; color: var(--muted); }

/* 人物 */
.sw-body { padding: 12px 16px 16px; }
.sw-tabs { display: flex; gap: 2px; margin: 0 0 12px; border-bottom: 1px solid var(--rule); }
.sw-tab { position: relative; min-height: 36px; padding: 4px 12px 6px; border: 0; background: none; color: var(--muted);
  font: 600 14px/1.2 var(--serif); letter-spacing: .06em; cursor: pointer; }
.sw-tab[aria-selected=true] { color: var(--ink); }
.sw-tab[aria-selected=true]::after { content: ''; position: absolute; left: 10px; right: 10px; bottom: -1px; height: 1px; background: var(--accent); }
.sw-who { display: grid; grid-template-columns: 56px minmax(0, 1fr); gap: 14px; align-items: start; animation: sw-in .5s ease-out both; }
.sw-face { width: 56px; height: 56px; border-radius: 50%; overflow: hidden; display: grid; place-items: center;
  font: 600 22px/1 var(--serif); color: var(--ink);
  background: #2a2a33; background: radial-gradient(circle at 35% 30%, color-mix(in srgb, var(--accent) 38%, #2a2a33), #1b1b22 78%);
  box-shadow: 0 0 0 1px #ffffff1f; }
.sw-face img { display: block; width: 100%; height: 100%; max-width: none; object-fit: cover; }
.sw-name { display: flex; flex-wrap: wrap; align-items: baseline; gap: 2px 10px; margin: 0; font: 600 18px/1.35 var(--serif); letter-spacing: .06em; }
.sw-mood { display: inline-flex; align-items: center; gap: 6px; font: 500 12px/1.5 system-ui, sans-serif; letter-spacing: .08em; color: var(--accent); }
.sw-mood::before { content: ''; width: 5px; height: 5px; border-radius: 50%; background: currentColor; opacity: .8; }
.sw-facts { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: 3px 12px; margin: 6px 0 0; font-size: 13px; line-height: 1.6; }
.sw-facts dt { color: var(--muted); font-size: 11px; letter-spacing: .1em; padding-top: 2px; }
.sw-facts dd { margin: 0; }
.sw-mind { position: relative; margin-top: 12px; padding: 8px 12px 10px 14px; border-left: 2px solid #ffffff22; border-left-color: var(--accent-soft);
  border-radius: 0 8px 8px 0; background: #ffffff07; }
.sw-mind-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-height: 18px; }
.sw-mind small { font-size: 10px; letter-spacing: .24em; color: var(--muted); }
.sw-mind p { margin: 2px 0 0; font: 400 14px/1.85 var(--serif); letter-spacing: .03em; transition: filter .6s, opacity .6s; }
.sw-mind[data-open=false] p { filter: blur(5px); opacity: .45; user-select: none; }
.sw-peek { position: absolute; inset: 0; width: 100%; border: 0; border-radius: inherit; background: #1111167a; color: var(--ink);
  font: 600 13px/1 var(--serif); letter-spacing: .16em; cursor: pointer; }
.sw-peek:hover, .sw-peek:focus-visible { background: #11111650; }
.sw-hide { min-height: 0; padding: 2px 6px; border: 0; background: none; color: var(--muted); font: inherit; font-size: 11px;
  letter-spacing: .1em; cursor: pointer; }
.sw-hide:hover { color: var(--ink); }
.sw-empty { margin: 0; color: var(--muted); font: 400 14px/1.6 var(--serif); letter-spacing: .08em; }

@container (max-width: 360px) {
  .sw-view { height: 104px; } .sw-place { font-size: 17px; } .sw-clock b { font-size: 21px; }
  .sw-who { grid-template-columns: 48px minmax(0, 1fr); gap: 12px; } .sw-face { width: 48px; height: 48px; font-size: 19px; }
}
@media (prefers-reduced-motion: reduce) { .sw, .sw * { animation: none !important; transition: none !important; } }

@keyframes sw-in { from { opacity: 0; } }
@keyframes sw-twinkle { to { opacity: calc(var(--o) * .3); } }
@keyframes sw-drift { to { transform: translateX(14%); } }
@keyframes sw-rain { from { transform: translate(0, 0) rotate(11deg); } to { transform: translate(-30px, 160px) rotate(11deg); } }
@keyframes sw-snow { from { transform: translate(0, 0); } to { transform: translate(var(--s), 160px); } }
@keyframes sw-petal { from { transform: translate(0, 0) rotate(0); } to { transform: translate(-70px, 160px) rotate(320deg); } }
@keyframes sw-slide { 0%, 55% { transform: translateY(0); opacity: 1; } 100% { transform: translateY(46px); opacity: 0; } }
`;

const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const text = (value) => (typeof value === 'string' ? value.trim() : '');
const isHttps = (value) => /^https:\/\//.test(text(value));
const pad = (value) => String(value).padStart(2, '0');

// 本音の前後に AI が付けた括弧は外す（表示のときに（ ）で囲み直す）。
const unwrap = (value) => value.replace(/^[「『（(“"]\s*/, '').replace(/\s*[」』）)”"]$/, '').trim();

// 描くたびに同じ位置になるよう、番号から決まる 0〜1 の値を使う。
function seeded(index, salt) {
  const value = Math.sin(index * 12.9898 + salt * 78.233) * 43758.5453;
  return value - Math.floor(value);
}

// "23:40"・"７：４２"・"7時42分" → { hour, minute }。読めなければ null。
function readTime(value) {
  const match = text(value).normalize('NFKC').match(/^(\d{1,2})\s*[:時]\s*(\d{1,2})\s*分?$/);
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour > 23 || minute > 59) return null;
  return { hour, minute };
}

// 時間帯。0〜3時は深夜、4〜5時は明け方、6〜9時は朝、10〜15時は昼、16〜18時は夕方、19時からは夜。
function periodOf(hour) {
  if (hour < 4) return 'late';
  if (hour < 6) return 'dawn';
  if (hour < 10) return 'morning';
  if (hour < 16) return 'day';
  if (hour < 19) return 'dusk';
  return 'night';
}

// clear・cloudy・rain・snow・petals のどれか。日本語でも読む。読めなければ晴れ。
function readWeather(value) {
  const word = text(value).toLowerCase();
  if (own(LABEL.weather, word)) return word;
  return own(WEATHER_WORDS, word) ? WEATHER_WORDS[word] : 'clear';
}

// 太陽は5時〜19時、月は19時〜翌5時に空を左から右へ渡る。
function orbPosition(hour, minute) {
  const now = hour + minute / 60;
  const sun = now >= 5 && now < 19;
  const progress = sun ? (now - 5) / 14 : ((((now - 19) % 24) + 24) % 24) / 10;
  return {
    moon: !sun,
    left: `${10 + progress * 80}%`,
    top: `${58 - Math.sin(progress * Math.PI) * 44}%`,
  };
}

// その場にいる人物。配列のほか、1人分のオブジェクトや JSON の文字列で届いても読む。
// 名前のない項目と、同じ名前の2人目は捨てる。ORDER の人を先頭にして3人まで。
function readCast(value) {
  let list = value;
  if (typeof list === 'string') {
    try {
      list = JSON.parse(list);
    } catch (error) {
      return [];
    }
  }
  if (list && typeof list === 'object' && !Array.isArray(list)) list = [list];
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const people = [];
  for (const person of list) {
    if (!person || typeof person !== 'object') continue;
    const name = text(person.name);
    if (!name || seen.has(name)) continue;
    seen.add(name);
    people.push({
      name,
      mood: text(person.mood),
      outfit: text(person.outfit),
      action: text(person.action),
      thought: unwrap(text(person.thought)),
      image: isHttps(person.image) ? text(person.image) : '',
    });
  }
  const rank = (name) => (ORDER.includes(name) ? ORDER.indexOf(name) : ORDER.length);
  return people
    .map((person, index) => ({ person, index }))
    .sort((a, b) => rank(a.person.name) - rank(b.person.name) || a.index - b.index)
    .map((entry) => entry.person)
    .slice(0, 3);
}

// 街並み。幅1200の中に建物を並べ、近い建物の窓は明かりが点いているものだけ描く。
// どの窓が点くかは番号から決まるので、描き直しても同じ窓が点く。
function buildCity(lit) {
  let far = '';
  let near = '';
  let windows = '';
  for (let x = -20, i = 0; x < 1200; i++) {
    const width = 44 + Math.round(seeded(i, 21) * 50);
    const height = 34 + Math.round(seeded(i, 22) * 30);
    far += `M${x} 80V${80 - height}h${width}V80Z`;
    x += width + Math.round(seeded(i, 23) * 6);
  }
  for (let x = -10, i = 0, k = 0; x < 1200; i++) {
    const width = 30 + Math.round(seeded(i, 31) * 40);
    const height = 16 + Math.round(seeded(i, 32) * 34);
    const top = 80 - height;
    near += `M${x} 80V${top}h${width}V80Z`;
    for (let wy = top + 6; wy + 4 < 78; wy += 9) {
      for (let wx = x + 5; wx + 4 < x + width - 3; wx += 9, k++) {
        if (seeded(k, 33) < lit) windows += `M${wx} ${wy}h4v4h-4Z`;
      }
    }
    x += width + Math.round(seeded(i, 34) * 4);
  }
  return { far, near, windows };
}

const FALL = { rain: 34, snow: 26, petals: 9 };

function Falling({ kind }) {
  const count = FALL[kind];
  if (!count) return null;
  const className = kind === 'petals' ? 'petal' : kind;
  return (
    <div className="sw-fall" aria-hidden="true">
      {Array.from({ length: count }, (_, i) => {
        const speed = { rain: 0.5 + seeded(i, 3) * 0.3, snow: 6 + seeded(i, 3) * 5, petals: 7 + seeded(i, 3) * 4 }[kind];
        return (
          <i
            key={i}
            className={className}
            style={{
              '--x': `${seeded(i, 1) * 110 - 2}%`,
              '--h': kind === 'rain' ? `${12 + seeded(i, 4) * 14}px` : `${2 + seeded(i, 4) * 3}px`,
              '--s': `${(seeded(i, 6) - 0.5) * 40}px`,
              '--t': `${speed}s`,
              '--w': `${-seeded(i, 5) * speed}s`,
            }}
          />
        );
      })}
      {kind === 'rain' &&
        Array.from({ length: 14 }, (_, i) => (
          <i
            key={`b${i}`}
            className={seeded(i, 41) < 0.35 ? 'bead slide' : 'bead'}
            style={{
              '--x': `${seeded(i, 42) * 96 + 2}%`,
              '--y': `${seeded(i, 43) * 80 + 4}%`,
              '--h': `${3 + seeded(i, 44) * 4}px`,
              '--t': `${7 + seeded(i, 45) * 6}s`,
              '--w': `${-seeded(i, 46) * 10}s`,
            }}
          />
        ))}
    </div>
  );
}

// 胸の内は、ボタンを押すまでぼかしておく。開け閉めしたらフォーカスを次のボタンへ移す（キーボードで続けて操作できるように）。
function Mind({ thought }) {
  const [open, setOpen] = useState(false);
  const peekRef = useRef(null);
  const hideRef = useRef(null);
  const moved = useRef(false);
  useEffect(() => {
    if (!moved.current) return;
    moved.current = false;
    const next = open ? hideRef.current : peekRef.current;
    if (next) next.focus();
  }, [open]);
  const toggle = (value) => {
    moved.current = true;
    setOpen(value);
  };
  return (
    <div className="sw-mind" data-open={open ? 'true' : 'false'}>
      <div className="sw-mind-head">
        <small>{LABEL.thought}</small>
        {open && (
          <button type="button" ref={hideRef} className="sw-hide" onClick={() => toggle(false)}>
            {LABEL.hide}
          </button>
        )}
      </div>
      <p aria-hidden={open ? undefined : 'true'}>{`（${thought}）`}</p>
      {!open && (
        <button type="button" ref={peekRef} className="sw-peek" onClick={() => toggle(true)}>
          {LABEL.peek}
        </button>
      )}
    </div>
  );
}

function Person({ person }) {
  const portrait = own(PORTRAITS, person.name) && isHttps(PORTRAITS[person.name]) ? PORTRAITS[person.name] : person.image;
  const [broken, setBroken] = useState(false);
  return (
    <div className="sw-who">
      <div className="sw-face" aria-hidden="true">
        {portrait && !broken ? <img src={portrait} alt="" onError={() => setBroken(true)} /> : [...person.name][0]}
      </div>
      <div>
        <p className="sw-name">
          {person.name}
          {person.mood && <span className="sw-mood">{person.mood}</span>}
        </p>
        {(person.outfit || person.action) && (
          <dl className="sw-facts">
            {person.outfit && (
              <>
                <dt>{LABEL.outfit}</dt>
                <dd>{person.outfit}</dd>
              </>
            )}
            {person.action && (
              <>
                <dt>{LABEL.action}</dt>
                <dd>{person.action}</dd>
              </>
            )}
          </dl>
        )}
        {person.thought && <Mind thought={person.thought} />}
      </div>
    </div>
  );
}

// 画面に見えているか。見えていないあいだは降るもののアニメを止める。
function useOnScreen(ref) {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const element = ref.current;
    if (!element || typeof IntersectionObserver !== 'function') return undefined;
    const observer = new IntersectionObserver((entries) => {
      setVisible(entries[entries.length - 1].isIntersecting);
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  return visible;
}

function StatusWindow(props) {
  const values = props || {};
  const place = text(values.place) || LABEL.somewhere;
  const date = text(values.date);
  const clock = readTime(values.time);
  const period = clock ? periodOf(clock.hour) : 'day';
  const weather = readWeather(values.weather);
  const palette = SKY[period];
  const orb = clock ? orbPosition(clock.hour, clock.minute) : orbPosition(12, 0);
  const cast = useMemo(() => readCast(values.cast), [values.cast]);
  const city = useMemo(() => buildCity(palette.lit), [palette]);
  const [selected, setSelected] = useState(0);
  const tabs = useRef([]);
  const root = useRef(null);
  const live = useOnScreen(root);
  const index = Math.min(selected, cast.length - 1);
  const current = cast[index];

  const stars = useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        left: `${seeded(i, 7) * 100}%`,
        top: `${seeded(i, 8) * 45}%`,
        '--o': (0.35 + seeded(i, 9) * 0.6) * palette.stars,
        '--d': `${2 + seeded(i, 10) * 3}s`,
      })),
    [palette],
  );

  // タブは左右の方向キーでも切り替える。
  const onTabKey = (event) => {
    const step = { ArrowRight: 1, ArrowLeft: -1 }[event.key];
    if (!step) return;
    event.preventDefault();
    const next = (index + step + cast.length) % cast.length;
    setSelected(next);
    const tab = tabs.current[next];
    if (tab) tab.focus();
  };

  return (
    <section
      ref={root}
      className="sw"
      data-weather={weather}
      data-live={live ? 'on' : 'off'}
      aria-label={`${place}の様子`}
      style={{
        '--s0': palette.sky[0],
        '--s1': palette.sky[1],
        '--s2': palette.sky[2],
        '--s3': palette.sky[3],
        '--c0': palette.city[0],
        '--c1': palette.city[1],
        '--glow': palette.glow,
        '--accent': palette.accent,
      }}
    >
      <style>{STYLE}</style>
      <div className="sw-view" aria-hidden="true">
        <div className="sw-scene">
          <div className="sw-sky" />
          {palette.stars > 0 && weather === 'clear' && stars.map((style, i) => <span key={i} className="sw-star" style={style} />)}
          <div className={orb.moon ? 'sw-moon' : 'sw-sun'} style={{ left: orb.left, top: orb.top }} />
          {(weather === 'cloudy' || weather === 'rain' || weather === 'snow') && (
            <>
              <span className="sw-cloud" style={{ left: '-8%', top: '2%' }} />
              <span className="sw-cloud" style={{ left: '44%', top: '-4%', animationDelay: '-18s' }} />
              <span className="sw-cloud" style={{ left: '20%', top: '24%', animationDelay: '-32s' }} />
            </>
          )}
          <svg className="sw-city" viewBox="0 0 1200 80" preserveAspectRatio="xMidYMax slice">
            <path className="far" d={city.far} />
            <path className="near" d={city.near} />
            {city.windows && <path className="lit" d={city.windows} />}
          </svg>
        </div>
        <Falling kind={weather} />
        <div className="sw-glass" />
        <div className="sw-curtain" />
        <div className="sw-frame" />
      </div>

      <div className="sw-head">
        <div className="sw-where">
          {date && <span className="sw-date">{date}</span>}
          <strong className="sw-place">{place}</strong>
        </div>
        <div className="sw-clock">
          {clock && <b>{`${pad(clock.hour)}:${pad(clock.minute)}`}</b>}
          <span>{clock ? `${LABEL.period[period]} · ${LABEL.weather[weather]}` : LABEL.weather[weather]}</span>
        </div>
      </div>

      <div className="sw-body">
        {cast.length > 1 && (
          <div className="sw-tabs" role="tablist" onKeyDown={onTabKey}>
            {cast.map((person, i) => (
              <button
                key={person.name}
                type="button"
                role="tab"
                ref={(element) => (tabs.current[i] = element)}
                className="sw-tab"
                aria-selected={i === index ? 'true' : 'false'}
                tabIndex={i === index ? 0 : -1}
                onClick={() => setSelected(i)}
              >
                {person.name}
              </button>
            ))}
          </div>
        )}
        {current ? <Person key={current.name} person={current} /> : <p className="sw-empty">{LABEL.nobody}</p>}
      </div>
    </section>
  );
}
